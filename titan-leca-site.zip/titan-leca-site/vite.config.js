import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// IMPORTANT: "base" must match your GitHub repository name exactly,
// e.g. if your repo is github.com/teu-user/titan-leca-app, keep it as below.
// If you rename the repo, update this value to match.
export default defineConfig({
  plugins: [react()],
  base: "/titan-leca-app/",
});
