# Titan Leça — Painel de Coaches

App simples para gerir alunos, planos de treino e avaliações físicas.

## O que precisas antes de começar

- Uma conta no [GitHub](https://github.com) (gratuita).
- O [Node.js](https://nodejs.org) instalado no computador (versão 18 ou mais recente) — é o que permite correr `npm`.
- O [Git](https://git-scm.com/downloads) instalado.

## 1. Testar localmente (opcional, mas recomendado)

Dentro desta pasta, no terminal:

```bash
npm install
npm run dev
```

Abre o link que aparecer (normalmente `http://localhost:5173`) para veres a app a funcionar antes de publicar.

## 2. Criar o repositório no GitHub

1. Entra em [github.com/new](https://github.com/new).
2. Nome do repositório: `titan-leca-app` (podes usar outro nome, mas depois tens de ajustar o passo 4).
3. Deixa-o **Público** (necessário para o GitHub Pages gratuito).
4. Não adiciones README, .gitignore nem licença — já estão nesta pasta.
5. Cria o repositório.

## 3. Enviar o código

No terminal, dentro desta pasta:

```bash
git init
git add .
git commit -m "primeira versão"
git branch -M main
git remote add origin https://github.com/O-TEU-USER/titan-leca-app.git
git push -u origin main
```

Substitui `O-TEU-USER` pelo teu utilizador do GitHub.

## 4. Confirmar o nome do repositório no vite.config.js

Abre `vite.config.js` e confirma que a linha `base` tem exatamente o nome do repositório que criaste, por exemplo:

```js
base: "/titan-leca-app/",
```

Se o repositório tiver outro nome, muda aqui para corresponder — senão o site fica com a aparência toda desformatada quando publicado.

## 5. Publicar no GitHub Pages

Ainda no terminal:

```bash
npm install
npm run deploy
```

Isto cria automaticamente uma branch `gh-pages` com o site já construído.

Depois, no GitHub: entra no repositório → **Settings** → **Pages** → em "Build and deployment", escolhe **Deploy from a branch**, seleciona a branch `gh-pages` e a pasta `/ (root)`. Guarda.

Ao fim de 1–2 minutos, o site fica disponível em:

```
https://O-TEU-USER.github.io/titan-leca-app/
```

Sempre que quiseres publicar alterações novas, basta repetir `npm run deploy`.

## Nota importante sobre os dados

Esta versão guarda os dados (alunos, planos, avaliações) no **armazenamento local do browser** (localStorage) de cada aparelho. Isto significa:

- Os dados **não são partilhados automaticamente** entre coaches diferentes, nem entre o teu telemóvel e o teu computador.
- Se limpares os dados do browser (ou usares modo privado/incógnito), os dados desaparecem.
- Cada coach que abrir o link tem a sua própria cópia local.

Se quiseres que todos os coaches vejam os mesmos dados em tempo real (ex: um aluno registado por um coach aparece logo para os outros), é preciso ligar a app a uma base de dados na nuvem — por exemplo o [Firebase](https://firebase.google.com) (tem um plano gratuito suficiente para isto). Isso é um passo extra que fica fora desta versão inicial, mas é possível adicionar depois.
